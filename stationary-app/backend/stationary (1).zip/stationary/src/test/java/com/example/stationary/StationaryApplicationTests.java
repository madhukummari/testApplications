package com.example.stationary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StationaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
